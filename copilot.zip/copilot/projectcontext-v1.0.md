# Instructions:
1. Refer details from the 'Project Context', 'Documentation', 'Technology Stack' while generating, reviewing code for the project.
2. Refer details from the 'Project Context', 'Documentation', 'Technology Stack', 'Testing' while generating unit test cases for the project.

# Project Context
1. Project Name: Web Crawler Test Generator Frontend
2. Project Description: A React-based Single Page Application for web crawling and automated test case generation. Features URL-driven crawling, LLM-powered test generation, and real-time progress tracking.
3. Additional Info: Frontend-only SPA that communicates with a Python backend API for crawl operations. Built with modern React patterns and TypeScript for type safety.
4. Project Type: Web Application
5. Project Category: Frontend Development
6. Project Subcategory: Single Page Application (SPA)
7. Project Stage: Development

# Documentation
1. Documentation: README.md, ARCHITECTURE.md, SETUP.md, API_INTEGRATION.md, PROJECT_SUMMARY.md, FILE_TREE.md, DELIVERY.md, QUICK_REFERENCE.md

# Technology Stack
1. Architecture: Component-based SPA with Service Layer
2. Frontend Technology: React 18.2.0 with Hooks
3. Backend Technology: Python REST API (external service)
4. Programming Language: TypeScript 5.2.0
5. Framework: Vite 5.0.0 (build tool), React Router v6 (routing)
6. Database: None (frontend-only, uses external API)
7. ORM: None
8. State Management: Zustand 4.4.0
9. HTTP Client: Axios 1.6.0
10. Styling: CSS Modules with CSS Variables
11. Build Tool: Vite 5.0.0 with Terser minification
12. Development Server: Vite dev server with HMR

# Testing
1. Testing: Vitest 0.34.0
2. Testing Framework: Vitest
3. Testing Library: React Testing Library, Jest DOM
4. Testing Type: Unit Testing, Component Testing
5. Test Runner: Vitest with UI support
6. Coverage: Vitest coverage reporting

# Code Repository
1. Code Repository: Git
2. Package Manager: npm
3. Version Control: Git with conventional commits
4. Branching Strategy: Feature branches from main

# Deployment
1. Deployment: Static site hosting (Vercel/Netlify/AWS S3)
2. CI/CD: GitHub Actions (planned)
3. CI/CD Pipeline: Automated testing and deployment
4. CI/CD Tools: GitHub Actions with Node.js
5. Environment: Development (local), Staging (planned), Production (planned)
6. Hosting: Static hosting service (Vercel/Netlify/AWS)
7. Hosting Type: Serverless/Static

# Project Structure
1. Source Directory: src/
2. Components: src/components/ (8 reusable components)
3. Pages: src/pages/ (single CrawlerPage)
4. Services: src/services/ (API client and crawler service)
5. Store: src/store/ (Zustand state management)
6. Hooks: src/hooks/ (custom React hooks)
7. Types: src/types/ (TypeScript definitions)
8. Utils: src/utils/ (configuration and helpers)
9. Styles: src/styles/ (global CSS)

# Key Features
1. Web Crawling: URL-based website crawling with authentication support
2. Test Generation: Automated test case generation using LLM
3. Real-time Monitoring: Live progress tracking with polling
4. Pipeline Visualization: 5-step process visualization
5. Log Management: Activity logging with capped history
6. File Operations: Download tests and Git repository integration
7. Error Handling: Comprehensive error boundaries and network error handling
8. Responsive Design: Mobile-friendly UI with dark theme support

# API Integration
1. Backend API: Python REST API at http://localhost:8000
2. Endpoints: 6 endpoints (start crawl, get status, cancel, download, push git, history)
3. Authentication: Bearer token support (planned)
4. Request Cancellation: AbortController-based request cancellation
5. Error Handling: Standardized error responses and retry logic

# Performance Characteristics
1. Bundle Size: ~150KB gzipped
2. Build Time: <1 second
3. Dev Server: 310ms startup time
4. Hot Module Replacement: Enabled
5. Memory Usage: Optimized with React.memo and selectors
6. Network Requests: Cancellable with exponential backoff retry

# Quality Assurance
1. TypeScript: Strict mode enabled
2. Linting: ESLint with React and TypeScript rules
3. Formatting: Prettier with consistent formatting
4. Testing: Unit tests for hooks and components
5. Code Coverage: Planned coverage reporting
6. Performance Audit: 36-checkpoint performance assessment completed
7. Security: CSP headers and input validation

# Development Workflow
1. Local Development: npm run dev (Vite dev server)
2. Building: npm run build (production build)
3. Testing: npm run test (unit tests)
4. Type Checking: npm run type-check
5. Linting: npm run lint
6. Formatting: npm run format